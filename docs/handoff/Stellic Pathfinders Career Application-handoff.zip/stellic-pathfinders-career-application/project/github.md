repo: Malamal32/Project
branch: main
path: (reference only — no UI in repo)

## Last sync
date: 2026-08-19T15:35:00Z

### Updated in this project
- Architecture update: frontend now targets the team's shared PostgreSQL hiring-market service (NCES CIP majors, O*NET occupations/alt titles, CIP-SOC crosswalks, postings, requirements) via API only — no direct DB access, no second database created here.
- api-service.js mocks the agreed contract: GET /api/roles/search?q=, POST /api/market/analyze (role/location/experience_level/remote_preference in, role+postings_found+postings_analyzed+skills[]/tools[]/credentials[]/experience[] out), plus transcript/resume mocks.
- Career Target role field now autocompletes against a mock O*NET occupation index; swap searchRoles/analyzeMarket bodies for real fetch() calls when the service is live — no other component changes needed.

## Screen map
| Screen | Repo files |
| --- | --- |
| (none built from repo) | — |
