# Academic Transcript Parsing Service

Parses an uploaded academic PDF (transcript, unofficial transcript, or degree
audit) into a structured, student-reviewable academic profile. Built around
Microsoft's [MarkItDown](https://github.com/microsoft/markitdown) for the
PDF → Markdown/text conversion step, plus a small rule-based normalizer —
no LLM, no invented fields.

## Pipeline

```
PDF upload
  -> validation (extension, MIME type, file signature, size, encryption, malformed check)
  -> write to a server-generated temp file (tempfile.mkstemp, random name)
  -> MarkItDown.convert_local(temp_path)   [plugins disabled, no URL fetching]
  -> extracted Markdown/text
  -> academic_extraction.normalize_academic_text()  [regex/heuristic only]
  -> structured JSON response
  -> temp file deleted in a finally block (always, success or failure)
```

## Files

- `app.py` — FastAPI app, exposes `POST /api/transcript/parse`.
- `pdf_validation.py` — all untrusted-input checks (extension, MIME, magic
  bytes, size, encryption, malformed PDF).
- `transcript_service.py` — orchestrates the pipeline; owns temp-file
  lifecycle and the scanned/image-only fallback.
- `academic_extraction.py` — pure functions that turn Markdown/text into an
  `AcademicProfile`. No I/O, no side effects — easy to unit test.
- `models.py` — Pydantic schemas (`Coursework`, `AcademicProfile`,
  `ParseResponse`).
- `config.py` — size limits and other constants.
- `tests/` — unit + integration tests using synthetic, generated PDFs only
  (no real student data).

## Endpoint

`POST /api/transcript/parse`
Content-Type: `multipart/form-data`, field name `file`.

Response (always this shape, whether or not parsing succeeded):

```json
{
  "success": true,
  "academic_profile": {
    "institution": "Riverbend State University",
    "degree": "Bachelor of Science",
    "degree_level": "Bachelor's",
    "major": "Computer Science",
    "minor": "Mathematics",
    "concentration": null,
    "graduation_date": null,
    "expected_graduation_date": "May 2027",
    "gpa": "3.72/4.00",
    "coursework": [
      { "id": "...", "course_code": "CS 310", "course_name": "Data Structures and Algorithms",
        "credits": 3.0, "grade": "A", "term": "Fall 2025", "student_approved": false }
    ],
    "honors": ["Dean's List, Fall 2025"],
    "certifications": ["AWS Cloud Practitioner"]
  },
  "warnings": [],
  "review_required": true
}
```

`review_required` is always `true` — the frontend must never write a field
to a resume without the student approving it first (`student_approved` on
each coursework row exists for this same reason).

## Security controls

- **Extension check**: filename must end in `.pdf`.
- **MIME type check**: multipart `Content-Type` must be `application/pdf`.
- **File signature check**: first bytes must be `%PDF-`.
- **Size cap**: 15 MB, enforced twice — while streaming the upload (so an
  oversized file can't be fully buffered into memory) and again on the final
  byte count.
- **Malformed PDF handling**: `pypdf.PdfReader` is used to open the file
  before MarkItDown ever sees it; any parse error is caught and turned into
  a clean validation message, never a raw exception/stack trace.
- **Encrypted/password-protected PDFs**: detected via `reader.is_encrypted`
  and rejected with a clear message before further processing.
- **No trusted user-supplied paths**: the request only ever carries a
  filename string (used for the extension check and, sanitized via
  `os.path.basename`, in log metadata) — no path from the client is ever
  used to open a file. The only filesystem path in the whole pipeline is
  the one `tempfile.mkstemp()` generates itself.
- **No arbitrary URL fetching**: `MarkItDown` is constructed with
  `enable_plugins=False`, and the code only ever calls `convert_local()` on
  the server-generated temp path — `convert_url()`/`convert()` on
  user-supplied URLs is never called.
- **Least-privilege library use**: only the local-file conversion entry
  point is used; no other MarkItDown format handlers (URL, YouTube, Office
  formats, etc.) are exercised.

## Temporary file behavior

- Created with `tempfile.mkstemp(prefix="transcript_", suffix=".pdf")` —
  a random, unpredictable name in the OS temp directory. The client never
  controls this path.
- Deleted in a `finally` block in `_run_markitdown_on_temp_file`, so it is
  removed whether conversion succeeds, raises, or the process is otherwise
  interrupted before the response is built.
- Nothing about the upload (bytes, filename content, extracted text) is
  written anywhere else — no database row, no cache, no log line. Logs only
  ever record byte size, extracted-character counts, and success/failure.

## Error behavior

Every failure path returns HTTP 200 with `success: false` and a
student-facing `warnings` message (never a stack trace), so the frontend can
render it inline and fall back to manual entry — except a genuinely oversized
upload, which is rejected at the transport layer with HTTP 413 before your
own size check even runs.

- Invalid extension / MIME / signature / empty file → `success: false`,
  explanatory warning.
- Encrypted PDF → `success: false`, "password-protected" warning.
- Malformed PDF → `success: false`, "may be corrupted" warning.
- MarkItDown raises for any other reason → `success: false`, generic
  "couldn't process this PDF" warning; full exception is logged server-side
  only (never the file content).
- Scanned/image-only PDF (extracted text below a minimum-length heuristic)
  → `success: false`, explicit warning telling the student to switch to
  manual entry; `academic_profile` is empty rather than guessed.
- Well-formed PDF with some fields not confidently found → `success: true`,
  `academic_profile` has those fields `null`/empty, and `warnings` lists
  which fields to double-check. `review_required` is always `true`.

## Run locally

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```

Test the endpoint:

```bash
curl -F "file=@/path/to/transcript.pdf" http://localhost:8000/api/transcript/parse
```

## Run tests

```bash
cd backend
pip install -r requirements.txt
pytest -v
```

Tests generate their own synthetic PDFs at run time (via `reportlab`/`pypdf`
fixtures in `tests/conftest.py`) — no real academic documents are used or
required.
