"""
PDF -> validation -> temporary processing -> MarkItDown -> normalization ->
structured JSON -> delete temporary file.

Every uploaded PDF is treated as untrusted. No uploaded document or its
extracted text is ever persisted to disk beyond the lifetime of a single
request, logged, or written to the market database.
"""
from __future__ import annotations

import logging
import os
import tempfile
from typing import List, Tuple

from markitdown import MarkItDown

from academic_extraction import normalize_academic_text
from config import MIN_EXTRACTED_CHARS
from models import AcademicProfile, ParseResponse
from pdf_validation import PdfValidationError, validate_upload

logger = logging.getLogger("transcript_service")

# Plugins disabled: we only need the built-in PDF text-extraction path, and
# plugins are the vector by which MarkItDown could reach out to fetch remote
# content. We also never call convert_url()/convert() on anything but a
# server-controlled local temp file path, so there is no way for a student's
# upload to make this service fetch an arbitrary URL.
_markitdown = MarkItDown(enable_plugins=False)


class ScannedDocumentError(Exception):
    """Raised when MarkItDown returns effectively no extractable text —
    almost always a scanned/image-only PDF with no text layer."""


def _run_markitdown_on_temp_file(content: bytes) -> str:
    """Writes to a server-controlled temp path (random name, our temp dir),
    converts with MarkItDown's narrowest local-file operation, and guarantees
    cleanup via try/finally regardless of success or failure."""
    fd, tmp_path = tempfile.mkstemp(suffix=".pdf", prefix="transcript_")
    try:
        with os.fdopen(fd, "wb") as tmp_file:
            tmp_file.write(content)
        result = _markitdown.convert_local(tmp_path)
        return result.text_content or ""
    finally:
        try:
            os.remove(tmp_path)
        except FileNotFoundError:
            pass


def parse_transcript_bytes(filename: str, content_type: str | None, content: bytes) -> ParseResponse:
    """Full pipeline for one upload. Never logs `content` or extracted text —
    only non-sensitive metadata (filename length/extension, byte size,
    success/failure) is logged."""
    logger.info("transcript upload received: size=%d bytes", len(content))

    try:
        validated = validate_upload(filename, content_type, content)
    except PdfValidationError as exc:
        logger.info("transcript upload rejected at validation: %s", exc)
        return ParseResponse(
            success=False,
            academic_profile=AcademicProfile(),
            warnings=[str(exc)],
            review_required=True,
        )

    try:
        extracted_text = _run_markitdown_on_temp_file(validated.content)
    except Exception:
        logger.exception("MarkItDown conversion failed")
        return ParseResponse(
            success=False,
            academic_profile=AcademicProfile(),
            warnings=[
                "We couldn't process this PDF. Please try again or enter your "
                "academic information manually."
            ],
            review_required=True,
        )

    if len(extracted_text.strip()) < MIN_EXTRACTED_CHARS:
        logger.info("transcript appears scanned/image-only: extracted_chars=%d", len(extracted_text.strip()))
        return ParseResponse(
            success=False,
            academic_profile=AcademicProfile(),
            warnings=[
                "This PDF appears to be a scanned image with no selectable text, "
                "so we couldn't extract information from it. Please enter your "
                "academic information manually."
            ],
            review_required=True,
        )

    profile, warnings = normalize_academic_text(extracted_text)
    return ParseResponse(success=True, academic_profile=profile, warnings=warnings, review_required=True)
