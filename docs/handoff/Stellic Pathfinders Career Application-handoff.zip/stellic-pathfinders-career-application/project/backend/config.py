"""Service-wide constants. No secrets here — safe to import anywhere."""

MAX_UPLOAD_BYTES = 15 * 1024 * 1024  # 15 MB hard cap
ALLOWED_EXTENSION = ".pdf"
ALLOWED_CONTENT_TYPES = {"application/pdf"}
PDF_MAGIC_BYTES = b"%PDF-"

# Heuristic: MarkItDown output shorter than this from a "normal" page count
# strongly suggests a scanned/image-only PDF with no extractable text layer.
MIN_EXTRACTED_CHARS = 40
