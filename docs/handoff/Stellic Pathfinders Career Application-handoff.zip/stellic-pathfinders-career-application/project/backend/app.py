"""FastAPI entrypoint. Run with: uvicorn app:app --reload --port 8000"""
from __future__ import annotations

import logging

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from config import MAX_UPLOAD_BYTES
from models import ParseResponse
from transcript_service import parse_transcript_bytes

logging.basicConfig(level=logging.INFO)

app = FastAPI(title="Pathfinder Transcript Parsing Service")

# Adjust allow_origins for your actual frontend origin(s) in production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["POST"],
    allow_headers=["*"],
)


@app.post("/api/transcript/parse", response_model=ParseResponse)
async def parse_transcript(file: UploadFile = File(...)) -> ParseResponse:
    # Read with a hard cap so an oversized upload can't exhaust memory before
    # our own size validation ever runs.
    chunks = []
    total = 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413, detail="File too large.")
        chunks.append(chunk)
    content = b"".join(chunks)

    return parse_transcript_bytes(
        filename=file.filename or "",
        content_type=file.content_type,
        content=content,
    )


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
