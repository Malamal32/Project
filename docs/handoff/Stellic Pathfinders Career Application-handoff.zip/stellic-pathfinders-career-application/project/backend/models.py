from typing import List, Optional
from pydantic import BaseModel, Field


class Coursework(BaseModel):
    id: str
    course_code: Optional[str] = None
    course_name: Optional[str] = None
    credits: Optional[float] = None
    grade: Optional[str] = None
    term: Optional[str] = None
    student_approved: bool = False


class AcademicProfile(BaseModel):
    institution: Optional[str] = None
    degree: Optional[str] = None
    degree_level: Optional[str] = None
    major: Optional[str] = None
    minor: Optional[str] = None
    concentration: Optional[str] = None
    graduation_date: Optional[str] = None
    expected_graduation_date: Optional[str] = None
    gpa: Optional[str] = None
    coursework: List[Coursework] = Field(default_factory=list)
    skills: List[str] = Field(default_factory=list)
    honors: List[str] = Field(default_factory=list)
    certifications: List[str] = Field(default_factory=list)


class ParseResponse(BaseModel):
    success: bool
    academic_profile: AcademicProfile
    warnings: List[str] = Field(default_factory=list)
    review_required: bool = True
