import io
import sys
from pathlib import Path

import pytest
from pypdf import PdfWriter
from reportlab.pdfgen import canvas

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def _pdf_with_text(lines: list[str]) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf)
    y = 780
    for line in lines:
        c.drawString(50, y, line)
        y -= 16
        if y < 40:
            c.showPage()
            y = 780
    c.save()
    return buf.getvalue()


@pytest.fixture
def synthetic_transcript_pdf() -> bytes:
    return _pdf_with_text([
        "Riverbend State University",
        "Official Academic Transcript",
        "Bachelor of Science",
        "Major: Computer Science",
        "Minor: Mathematics",
        "Expected Graduation: May 2027",
        "GPA: 3.72/4.00",
        "",
        "## Coursework",
        "CS 310 - Data Structures and Algorithms - 3 cr - Grade: A - Fall 2025",
        "CS 340 - Database Systems - 3 cr - Grade: A- - Spring 2025",
        "MATH 251 - Statistics I - 3 cr - Grade: B+ - Fall 2024",
        "",
        "## Honors",
        "- Dean's List, Fall 2025",
        "",
        "## Certifications",
        "- AWS Cloud Practitioner",
    ])


@pytest.fixture
def synthetic_minimal_pdf() -> bytes:
    # Deliberately sparse: exercises the "couldn't confidently identify" warnings.
    return _pdf_with_text(["Some Document", "No structured academic fields here."])


@pytest.fixture
def synthetic_blank_pdf() -> bytes:
    # No text layer at all -> should be treated like a scanned/image-only PDF.
    buf = io.BytesIO()
    c = canvas.Canvas(buf)
    c.rect(100, 100, 10, 10)  # a shape, no text
    c.save()
    return buf.getvalue()


@pytest.fixture
def synthetic_encrypted_pdf(synthetic_transcript_pdf: bytes) -> bytes:
    reader_bytes = io.BytesIO(synthetic_transcript_pdf)
    from pypdf import PdfReader

    reader = PdfReader(reader_bytes)
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    writer.encrypt(user_password="secret", owner_password="secret")
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()
