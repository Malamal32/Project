import io
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from transcript_service import parse_transcript_bytes


def test_valid_transcript_end_to_end(synthetic_transcript_pdf):
    response = parse_transcript_bytes("transcript.pdf", "application/pdf", synthetic_transcript_pdf)
    assert response.success is True
    assert response.review_required is True
    assert response.academic_profile.institution == "Riverbend State University"
    assert response.academic_profile.gpa == "3.72/4.00"
    assert len(response.academic_profile.coursework) == 3


def test_minimal_document_returns_warnings_not_fabrication(synthetic_minimal_pdf):
    response = parse_transcript_bytes("doc.pdf", "application/pdf", synthetic_minimal_pdf)
    assert response.success is True
    assert response.academic_profile.institution is None
    assert len(response.warnings) > 0


def test_scanned_image_only_pdf_falls_back(synthetic_blank_pdf):
    response = parse_transcript_bytes("scan.pdf", "application/pdf", synthetic_blank_pdf)
    assert response.success is False
    assert response.review_required is True
    assert any("scanned" in w.lower() for w in response.warnings)


def test_encrypted_pdf_is_rejected(synthetic_encrypted_pdf):
    response = parse_transcript_bytes("locked.pdf", "application/pdf", synthetic_encrypted_pdf)
    assert response.success is False
    assert any("password" in w.lower() for w in response.warnings)


def test_wrong_extension_is_rejected(synthetic_transcript_pdf):
    response = parse_transcript_bytes("transcript.txt", "application/pdf", synthetic_transcript_pdf)
    assert response.success is False
    assert any("PDF" in w for w in response.warnings)


def test_wrong_content_type_is_rejected(synthetic_transcript_pdf):
    response = parse_transcript_bytes("transcript.pdf", "text/plain", synthetic_transcript_pdf)
    assert response.success is False


def test_bad_signature_is_rejected():
    response = parse_transcript_bytes("fake.pdf", "application/pdf", b"not a real pdf")
    assert response.success is False


def test_oversized_file_is_rejected(synthetic_transcript_pdf):
    from config import MAX_UPLOAD_BYTES

    oversized = synthetic_transcript_pdf + b"0" * (MAX_UPLOAD_BYTES + 1)
    response = parse_transcript_bytes("big.pdf", "application/pdf", oversized)
    assert response.success is False
    assert any("MB" in w for w in response.warnings)


def test_empty_file_is_rejected():
    response = parse_transcript_bytes("empty.pdf", "application/pdf", b"")
    assert response.success is False


def test_markitdown_failure_does_not_leave_temp_file(synthetic_transcript_pdf, tmp_path):
    """Confirms cleanup runs even when MarkItDown raises."""
    with patch("transcript_service._markitdown.convert_local", side_effect=RuntimeError("boom")):
        response = parse_transcript_bytes("transcript.pdf", "application/pdf", synthetic_transcript_pdf)
    assert response.success is False
    import glob
    import tempfile

    leftover = glob.glob(str(Path(tempfile.gettempdir()) / "transcript_*"))
    assert leftover == []
