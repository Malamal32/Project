// Mock API service layer standing in for the shared PostgreSQL hiring-market
// database (NCES CIP majors, O*NET occupations/alt titles, CIP-SOC crosswalks,
// companies, job postings, posting requirements). The frontend never touches
// that database directly — it only calls the functions below, which mirror
// the planned endpoints:
//
//   GET  /api/roles/search?q=            -> searchRoles(q)
//   POST /api/market/analyze             -> analyzeMarket({ role, location, experience_level, remote_preference })
//   POST /api/transcript/parse           -> parseTranscript(file)
//   POST /api/resume/generate            -> generateResume({ career, academic, topSkills, variant })
//
// When the real market-database service is ready, replace only the bodies of
// searchRoles/analyzeMarket with fetch() calls — callers depend solely on
// these signatures and response shapes.

// ---------------------------------------------------------------------------
// NOTE: StudentProfile + MarketProfile -> MarketMatch
//
// This mirrors backend/market_matching.py exactly (same statuses, same
// conservative rules, same evidence requirement) so the frontend behaves
// identically to the real matching service once it's wired to a live API.
// It never touches a database and never infers a skill from market demand
// alone — demand only decides which skills are worth checking.
// ---------------------------------------------------------------------------

function slugify(name) {
  return (name || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
}

function wordMatch(haystack, needle) {
  if (!haystack) return false;
  const escaped = needle.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp('(?<![a-z0-9])' + escaped + '(?![a-z0-9])');
  return re.test(haystack.toLowerCase());
}

const TOP_N_SKILLS = 10;

/**
 * matchMarket(studentProfile, marketProfile) -> MarketMatch
 * StudentProfile: { skills:[{id,name,aliases?}], certifications:[{id,name}],
 *   coursework:[{id,course_code?,course_name}], experience:[{id,description}],
 *   projects:[{id,technologies,description}] }
 * MarketProfile: { skills:[{id?,name,posting_count,frequency}] }
 */
export function matchMarket(studentProfile, marketProfile) {
  const sp = {
    skills: studentProfile.skills || [], certifications: studentProfile.certifications || [],
    coursework: studentProfile.coursework || [], experience: studentProfile.experience || [], projects: studentProfile.projects || []
  };
  const topSkills = (marketProfile.skills || []).slice(0, TOP_N_SKILLS);

  const checkVerified = (name) => {
    const pool = [...sp.skills, ...sp.certifications];
    const hit = pool.find(item => item.name.toLowerCase() === name.toLowerCase() || (item.aliases || []).some(a => a.toLowerCase() === name.toLowerCase()));
    return hit ? [hit.id] : null;
  };
  const checkCoursework = (name) => {
    const hit = sp.coursework.find(c => wordMatch(c.course_name, name) || wordMatch(c.course_code, name));
    return hit ? [hit.id] : null;
  };
  const checkTransferable = (name) => {
    const expHit = sp.experience.find(e => wordMatch(e.description, name));
    if (expHit) return [expHit.id];
    const projHit = sp.projects.find(p => wordMatch(`${p.technologies || ''} ${p.description || ''}`, name));
    return projHit ? [projHit.id] : null;
  };

  const matches = topSkills.map(sk => {
    const market_skill_id = sk.id || slugify(sk.name);
    let evidence = checkVerified(sk.name), status = 'verified';
    if (!evidence) { evidence = checkCoursework(sk.name); status = 'coursework'; }
    if (!evidence) { evidence = checkTransferable(sk.name); status = 'transferable'; }
    if (!evidence) { evidence = []; status = 'not_verified'; }
    return { market_skill_id, market_skill: sk.name, posting_count: sk.posting_count, frequency: sk.frequency, status, evidence };
  });

  const verified_top_skills = matches.filter(m => m.status !== 'not_verified').length;
  const gaps = matches.filter(m => m.status === 'not_verified').map(m => m.market_skill);
  return { summary: { top_market_skills_considered: topSkills.length, verified_top_skills }, matches, gaps };
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

// Stand-in for an O*NET occupation index the real /api/roles/search will query.
const ROLE_INDEX = [
  { display_name: 'Software Developer', onet_soc_code: '15-1252.00', key: 'swe', alt: ['backend developer', 'frontend developer', 'full stack developer', 'software engineer', 'application developer'] },
  { display_name: 'Data Analyst', onet_soc_code: '15-2051.00', key: 'data', alt: ['business intelligence analyst', 'reporting analyst'] },
  { display_name: 'Marketing Specialist', onet_soc_code: '11-2021.00', key: 'marketing', alt: ['digital marketing coordinator', 'brand marketing associate'] },
  { display_name: 'Financial Analyst', onet_soc_code: '13-2051.00', key: 'finance', alt: ['investment analyst', 'equity research analyst'] },
  { display_name: 'UX/Product Designer', onet_soc_code: '15-1255.00', key: 'design', alt: ['ux designer', 'product designer', 'ui designer'] },
  { display_name: 'Accountant', onet_soc_code: '13-2011.00', key: 'accounting', alt: ['staff accountant', 'junior accountant'] },
  { display_name: 'Registered Nurse', onet_soc_code: '29-1141.00', key: 'nursing', alt: ['rn', 'nurse'] },
  { display_name: 'Mechanical Engineer', onet_soc_code: '17-2141.00', key: 'mech_engineering', alt: ['civil engineer', 'manufacturing engineer'] },
  { display_name: 'Human Resources Specialist', onet_soc_code: '13-1071.00', key: 'hr', alt: ['hr coordinator', 'recruiter', 'talent acquisition specialist'] },
  { display_name: 'Sales Representative', onet_soc_code: '41-4012.00', key: 'sales', alt: ['account executive', 'business development representative'] },
  { display_name: 'Elementary/Secondary Teacher', onet_soc_code: '25-2021.00', key: 'teaching', alt: ['teacher', 'instructor'] },
  { display_name: 'Petroleum Engineer', onet_soc_code: '17-2171.00', key: 'petroleum', alt: ['reservoir engineer', 'drilling engineer'] },
  { display_name: 'Electrical Engineer', onet_soc_code: '17-2071.00', key: 'electrical_engineering', alt: ['computer hardware engineer', 'embedded systems engineer'] },
  { display_name: 'Logistician', onet_soc_code: '13-1081.00', key: 'supply_chain', alt: ['supply chain analyst', 'logistics coordinator'] },
  { display_name: 'Construction Manager', onet_soc_code: '11-9021.00', key: 'construction', alt: ['construction project manager'] },
  { display_name: 'Agricultural Manager', onet_soc_code: '11-9013.00', key: 'agriculture', alt: ['farm manager', 'agribusiness specialist'] },
  { display_name: 'Exercise Physiologist', onet_soc_code: '29-1128.00', key: 'kinesiology', alt: ['fitness trainer', 'athletic trainer'] },
  { display_name: 'Police & Detective', onet_soc_code: '33-3051.00', key: 'criminal_justice', alt: ['probation officer', 'correctional officer'] },
  { display_name: 'Public Relations Specialist', onet_soc_code: '27-3031.00', key: 'communications', alt: ['communications coordinator', 'pr associate'] },
  { display_name: 'Medical Scientist', onet_soc_code: '19-1042.00', key: 'biology_prehealth', alt: ['research associate', 'lab technician'] }
];

/** GET /api/roles/search?q= — mock O*NET occupation/alt-title lookup. */
export async function searchRoles(q) {
  await delay(220);
  const query = (q || '').trim().toLowerCase();
  if (!query) return [];
  return ROLE_INDEX
    .filter(r => r.display_name.toLowerCase().includes(query) || r.alt.some(a => a.includes(query)))
    .slice(0, 8)
    .map(r => ({ display_name: r.display_name, onet_soc_code: r.onet_soc_code }));
}

function mapRoleToProfileKey(role) {
  const r = (role || '').toLowerCase();
  const hit = ROLE_INDEX.find(e => e.display_name.toLowerCase() === r || e.alt.includes(r));
  if (hit) return hit.key;
  if (/petroleum|reservoir|drilling|upstream energy/.test(r)) return 'petroleum';
  if (/electrical engineer|computer engineer|embedded/.test(r)) return 'electrical_engineering';
  if (/supply chain|logistics|procurement/.test(r)) return 'supply_chain';
  if (/construction/.test(r)) return 'construction';
  if (/agricultur|agribusiness|ranch|farm/.test(r)) return 'agriculture';
  if (/kinesiology|exercise science|athletic train|personal train/.test(r)) return 'kinesiology';
  if (/criminal justice|law enforcement|corrections|forensic/.test(r)) return 'criminal_justice';
  if (/communications|public relations|\bpr\b|journalism/.test(r)) return 'communications';
  if (/biology|pre-health|pre-med|biomedical science/.test(r)) return 'biology_prehealth';
  if (/nurs|rn\b|clinical|patient care/.test(r)) return 'nursing';
  if (/mechanical|civil|structural|manufactur/.test(r)) return 'mech_engineering';
  if (/accountant|accounting|bookkeep|audit/.test(r)) return 'accounting';
  if (/human resources|^hr\b| hr |recruit/.test(r)) return 'hr';
  if (/sales|account executive|business development/.test(r)) return 'sales';
  if (/teach|educat|instructor/.test(r)) return 'teaching';
  if (/design|ux|ui|product design/.test(r)) return 'design';
  if (/market/.test(r)) return 'marketing';
  if (/financ/.test(r)) return 'finance';
  if (/data analy|analytics/.test(r)) return 'data';
  if (/software|develop|engineer|program/.test(r)) return 'swe';
  return 'general';
}

function onetCodeFor(key) {
  const hit = ROLE_INDEX.find(e => e.key === key);
  return hit ? hit.onet_soc_code : '';
}

// Temporary development mock data standing in for the shared postings DB.
// Skill "frequency" is computed server-side as:
//   (unique relevant postings containing the skill) / (unique relevant postings analyzed)
// — there is no static universal market-value number; these mock profiles
// just pre-bake a plausible result of that computation per occupation.
const MOCK_MARKET_PROFILES = {
  swe: { postings_found: 2140, postings_analyzed: 1876, skills: [
    ['SQL',1388,0.740],['Python',1257,0.670],['Git',1144,0.610],['REST APIs',1032,0.550],['JavaScript',957,0.510],
    ['Linux',844,0.450],['AWS',807,0.430],['Docker',750,0.400],['Agile/Scrum',675,0.360],['Unit Testing',582,0.310]
  ], sample_postings: [
    { title: 'Junior Backend Developer', company: 'Lonestar Digital', location: 'Austin, TX', skills: ['SQL','Python','Git','REST APIs'] },
    { title: 'Software Engineer I', company: 'Meridian Systems', location: 'Remote', skills: ['Python','Git','AWS','Docker'] },
    { title: 'Application Developer, New Grad', company: 'Highline Software', location: 'Dallas, TX', skills: ['SQL','JavaScript','REST APIs','Unit Testing'] },
    { title: 'Platform Engineer I', company: 'Cobalt Cloud', location: 'Austin, TX', skills: ['Linux','AWS','Docker','Agile/Scrum'] }
  ]},
  data: { postings_found: 1860, postings_analyzed: 1612, skills: [
    ['SQL',1306,0.810],['Excel',1161,0.720],['Python',1048,0.650],['Data Visualization',935,0.580],['Tableau',903,0.560],
    ['Power BI',758,0.470],['Statistics',709,0.440],['Communication',629,0.390],['A/B Testing',532,0.330],['R',451,0.280]
  ], sample_postings: [
    { title: 'Junior Data Analyst', company: 'Alamo Insights', location: 'San Antonio, TX', skills: ['SQL','Excel','Data Visualization'] },
    { title: 'Business Intelligence Analyst I', company: 'Northgate Retail', location: 'Remote', skills: ['SQL','Tableau','Power BI'] },
    { title: 'Reporting Analyst, New Grad', company: 'Prairie Analytics', location: 'Houston, TX', skills: ['Excel','Python','Statistics'] }
  ]},
  marketing: { postings_found: 1520, postings_analyzed: 1339, skills: [
    ['Content Creation',830,0.620],['Social Media Strategy',777,0.580],['SEO',737,0.550],['Google Analytics',683,0.510],['Copywriting',629,0.470],
    ['Email Marketing',589,0.440],['Adobe Creative Suite',536,0.400],['Campaign Management',509,0.380],['CRM (HubSpot/Salesforce)',442,0.330],['Project Management',402,0.300]
  ]},
  finance: { postings_found: 1310, postings_analyzed: 1147, skills: [
    ['Excel',906,0.790],['Financial Modeling',700,0.610],['PowerPoint',574,0.500],['Forecasting',539,0.470],['Data Analysis',505,0.440],
    ['SQL',482,0.420],['GAAP',378,0.330],['Valuation',344,0.300],['VBA',287,0.250],['Bloomberg Terminal',252,0.220]
  ]},
  design: { postings_found: 980, postings_analyzed: 861, skills: [
    ['Figma',611,0.710],['User Research',499,0.580],['Wireframing',474,0.550],['Prototyping',448,0.520],['Usability Testing',379,0.440],
    ['Design Systems',344,0.400],['Interaction Design',327,0.380],['Cross-functional Collaboration',301,0.350],['HTML/CSS',284,0.330],['Accessibility',232,0.270]
  ]},
  accounting: { postings_found: 1180, postings_analyzed: 1029, skills: [
    ['Excel',793,0.770],['GAAP',617,0.600],['QuickBooks',545,0.530],['Account Reconciliation',494,0.480],['Accounts Payable/Receivable',463,0.450],
    ['Tax Preparation',401,0.390],['Auditing',370,0.360],['Financial Reporting',350,0.340],['ERP Systems (SAP/Oracle)',298,0.290],['Attention to Detail',267,0.260]
  ]},
  nursing: { postings_found: 1670, postings_analyzed: 1451, skills: [
    ['Patient Care',1263,0.870],['Electronic Health Records (EHR)',972,0.670],['Clinical Assessment',856,0.590],['Medication Administration',798,0.550],['BLS/ACLS Certification',726,0.500],
    ['Care Planning',653,0.450],['IV Therapy',566,0.390],['Infection Control',508,0.350],['Patient Education',464,0.320],['Triage',392,0.270]
  ]},
  mech_engineering: { postings_found: 1040, postings_analyzed: 902, skills: [
    ['CAD (SolidWorks/AutoCAD)',703,0.780],['Finite Element Analysis (FEA)',469,0.520],['GD&T',415,0.460],['MATLAB',379,0.420],['Project Management',343,0.380],
    ['Manufacturing Processes',316,0.350],['Materials Science',289,0.320],['Structural Analysis',262,0.290],['Quality Control',235,0.260],['Technical Documentation',199,0.220]
  ]},
  hr: { postings_found: 890, postings_analyzed: 774, skills: [
    ['Recruiting',565,0.730],['Onboarding',465,0.600],['HRIS (Workday/ADP)',403,0.520],['Employee Relations',372,0.480],['Benefits Administration',325,0.420],
    ['Performance Management',294,0.380],['Employment Law Compliance',263,0.340],['Applicant Tracking Systems',232,0.300],['Communication',209,0.270],['Conflict Resolution',178,0.230]
  ]},
  sales: { postings_found: 1390, postings_analyzed: 1211, skills: [
    ['CRM (Salesforce/HubSpot)',908,0.750],['Prospecting',738,0.610],['Cold Calling',654,0.540],['Negotiation',605,0.500],['Pipeline Management',545,0.450],
    ['Quota Attainment',484,0.400],['Presentation Skills',424,0.350],['Account Management',388,0.320],['Lead Generation',351,0.290],['Communication',315,0.260]
  ]},
  teaching: { postings_found: 760, postings_analyzed: 661, skills: [
    ['Lesson Planning',522,0.790],['Classroom Management',449,0.680],['Curriculum Development',383,0.580],['Differentiated Instruction',317,0.480],['Student Assessment',284,0.430],
    ['IEP/504 Support',251,0.380],['Parent Communication',218,0.330],['Educational Technology',191,0.290],['State Teaching Certification',165,0.250],['Student Engagement',145,0.220]
  ]},
  petroleum: { postings_found: 640, postings_analyzed: 556, skills: [
    ['Reservoir Simulation',400,0.720],['Drilling Operations',361,0.650],['Petrel/Eclipse',300,0.540],['Well Completions',267,0.480],['Production Optimization',233,0.420],
    ['HSE Compliance',200,0.360],['MATLAB',178,0.320],['Geomechanics',156,0.280],['Data Analysis',133,0.240],['Project Management',111,0.200]
  ]},
  electrical_engineering: { postings_found: 970, postings_analyzed: 844, skills: [
    ['Circuit Design',641,0.760],['PCB Layout',464,0.550],['Embedded C/C++',431,0.510],['MATLAB/Simulink',397,0.470],['Signal Processing',355,0.420],
    ['FPGA/VHDL',313,0.370],['Power Systems',279,0.330],['Python',245,0.290],['Testing & Debugging',211,0.250],['Technical Documentation',178,0.210]
  ]},
  supply_chain: { postings_found: 880, postings_analyzed: 766, skills: [
    ['Inventory Management',590,0.770],['ERP Systems (SAP/Oracle)',490,0.640],['Demand Forecasting',421,0.550],['Procurement',383,0.500],['Excel',352,0.460],
    ['Logistics Planning',314,0.410],['Vendor Management',275,0.360],['Lean/Six Sigma',237,0.310],['Data Analysis',199,0.260],['Project Management',168,0.220]
  ]},
  construction: { postings_found: 710, postings_analyzed: 618, skills: [
    ['Project Scheduling',476,0.770],['Blueprint Reading',407,0.660],['Cost Estimating',358,0.580],['Procore/Bluebeam',315,0.510],['OSHA Safety Standards',278,0.450],
    ['Contract Administration',235,0.380],['MS Project',198,0.320],['Quality Control',167,0.270],['Site Supervision',142,0.230],['Budget Management',117,0.190]
  ]},
  agriculture: { postings_found: 520, postings_analyzed: 452, skills: [
    ['Crop Science',335,0.740],['Precision Agriculture Tech',271,0.600],['Farm/Ranch Operations',235,0.520],['Agribusiness Management',199,0.440],['Soil Science',172,0.380],
    ['GIS Mapping',149,0.330],['Excel',127,0.280],['Regulatory Compliance',108,0.240],['Livestock Management',90,0.200],['Communication',72,0.160]
  ]},
  kinesiology: { postings_found: 460, postings_analyzed: 401, skills: [
    ['Exercise Programming',297,0.740],['Fitness Assessment',241,0.600],['CPR/AED Certification',208,0.520],['Injury Prevention',176,0.440],['Anatomy & Physiology',152,0.380],
    ['Client Coaching',132,0.330],['Rehabilitation Protocols',112,0.280],['Nutrition Fundamentals',96,0.240],['Client Record Keeping',80,0.200],['Communication',64,0.160]
  ]},
  criminal_justice: { postings_found: 610, postings_analyzed: 531, skills: [
    ['Report Writing',393,0.740],['Legal Procedures',329,0.620],['Investigative Techniques',281,0.530],['Evidence Handling',244,0.460],['Crisis De-escalation',212,0.400],
    ['Public Safety Protocols',180,0.340],['Records Management',154,0.290],['Communication',132,0.250],['Community Relations',112,0.210],['Conflict Resolution',91,0.170]
  ]},
  communications: { postings_found: 700, postings_analyzed: 609, skills: [
    ['Content Writing',462,0.760],['Media Relations',371,0.610],['Social Media Strategy',335,0.550],['Press Releases',292,0.480],['Brand Messaging',250,0.410],
    ['Adobe Creative Suite',213,0.350],['Public Speaking',183,0.300],['Crisis Communications',152,0.250],['Google Analytics',128,0.210],['Event Planning',104,0.170]
  ]},
  biology_prehealth: { postings_found: 540, postings_analyzed: 470, skills: [
    ['Laboratory Techniques',366,0.780],['Data Collection & Analysis',296,0.630],['Research Methods',254,0.540],['Microscopy',216,0.460],['Patient Interaction',183,0.390],
    ['Regulatory Compliance',155,0.330],['Medical Terminology',132,0.280],['Excel',113,0.240],['Scientific Writing',94,0.200],['Lab Safety Protocols',75,0.160]
  ]},
  general: { postings_found: 1440, postings_analyzed: 1268, skills: [
    ['Communication',735,0.580],['Microsoft Office',697,0.550],['Teamwork',634,0.500],['Problem Solving',596,0.470],['Project Management',558,0.440],
    ['Data Analysis',507,0.400],['Time Management',482,0.380],['Customer Service',419,0.330],['Presentation Skills',380,0.300],['Adaptability',355,0.280]
  ], sample_postings: [
    { title: 'Business Operations Associate', company: 'Sabine Group', location: 'Austin, TX', skills: ['Communication','Microsoft Office','Problem Solving'] },
    { title: 'Coordinator, New Grad Program', company: 'Republic Holdings', location: 'Dallas, TX', skills: ['Teamwork','Project Management','Time Management'] }
  ]}
};

const DATA_AS_OF = '2026-08-19';

/**
 * POST /api/market/analyze
 * request: { role, location, experience_level, remote_preference }
 * response matches the shared market-database service contract:
 * { role:{display_name,onet_soc_code}, postings_found, postings_analyzed, data_as_of, skills[], tools[], credentials[], experience[] }
 */
export async function analyzeMarket({ role, location, experience_level, remote_preference } = {}) {
  await delay(2600);
  const key = mapRoleToProfileKey(role);
  const profile = MOCK_MARKET_PROFILES[key];
  return {
    role: { display_name: role || 'General', onet_soc_code: onetCodeFor(key) },
    postings_found: profile.postings_found,
    postings_analyzed: profile.postings_analyzed,
    data_as_of: DATA_AS_OF,
    skills: profile.skills.map(([name, posting_count, frequency]) => ({ name, posting_count, frequency })),
    tools: [],
    credentials: [],
    experience: [],
    sample_postings: profile.sample_postings || []
  };
}

/**
 * POST /api/transcript/parse
 * Reads the student's real PDF in the browser (pdf.js text layer) and
 * normalizes it with the same rule-based logic as backend/academic_extraction.py.
 * The file is never uploaded, stored, or logged. Returns
 * { success, academic_profile, warnings, review_required } — on failure the
 * profile is empty so the student can fall back to manual entry.
 */
export async function parseTranscript(file) {
  const { parsePdfFile, PdfValidationError } = await import('./academic-extraction.js');
  const empty = { institution:'', degree:'', degreeLevel:'', major:'', minor:'', concentration:'', gradDate:'', gpa:'', coursework:[], skills:[], certifications:[], honors:[] };
  try {
    const { profile, warnings } = await parsePdfFile(file);
    return { success: true, academic_profile: profile, warnings, review_required: true };
  } catch (err) {
    const message = err instanceof PdfValidationError
      ? err.message
      : "We couldn't process this PDF. Please enter your academic information manually.";
    return { success: false, academic_profile: empty, warnings: [message], review_required: true };
  }
}

/** Development fixture kept for reference/testing only — not used by the app. */
export function mockTranscriptProfile() {
  return {
    institution: 'Riverbend State University',
    degree: 'Bachelor of Science',
    degreeLevel: 'Bachelor of Science',
    major: 'Computer Science',
    minor: '',
    gradDate: 'May 2027',
    gpa: '',
    coursework: ['Data Structures & Algorithms', 'Database Systems', 'Software Engineering', 'Statistics I'],
    skills: ['Python', 'SQL', 'Git'],
    certifications: [],
    honors: ["Dean's List, Fall 2025"]
  };
}

const SUMMARY_TEMPLATES = [
  (c, a, skills) => `${c.level || 'Entry level'} ${c.role || 'candidate'} with a background in ${a.major || 'their field'} from ${a.institution || 'their university'}, with verified strength in ${skills}.`,
  (c, a, skills) => `${a.degreeLevel || 'Student'} in ${a.major || 'their field'} at ${a.institution || 'their university'}, pursuing ${c.role || 'a role in the field'}, with demonstrated ability in ${skills}.`,
  (c, a, skills) => `Motivated ${c.level || 'entry-level'} professional targeting ${c.role || 'roles in the field'}, backed by coursework and hands-on work in ${skills}.`
];

/** POST /api/resume/generate — mock resume-copy generation from verified inputs. */
export async function generateResume({ career, academic, topSkills, variant }) {
  await delay(500);
  const fn = SUMMARY_TEMPLATES[(variant || 0) % SUMMARY_TEMPLATES.length];
  return { summary: fn(career || {}, academic || {}, (topSkills && topSkills.length) ? topSkills.join(', ') : 'their coursework') };
}
